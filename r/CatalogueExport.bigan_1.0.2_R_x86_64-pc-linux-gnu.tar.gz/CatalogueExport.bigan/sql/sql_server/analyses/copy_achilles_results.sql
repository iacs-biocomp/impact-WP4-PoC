-- todo copy a specific analysis_id from the achilles_result table to the catalogue_results table
-- option: get the list on analysis_ids from the achilles table and remove those from the current list
--         then add all those in achilles in a temp and merge that with the added queries
--         by default re-use the once executed by achilles


