-- 730	Number of descendant drug exposure records,by procedure_concept_id

--HINT DISTRIBUTE_ON_KEY(stratum_1)

SELECT 730 as analysis_id,
  CAST(ca.ancestor_concept_id AS VARCHAR(255)) AS stratum_1,
  cast(null as varchar(255)) AS stratum_2,
  cast(null as varchar(255)) as stratum_3,
  cast(null as varchar(255)) as stratum_4,
  cast(null as varchar(255)) as stratum_5,
  floor((sum(drc)+99)/100)*100 as count_value
into @scratchDatabaseSchema@schemaDelim@tempAchillesPrefix_730
from 
	(select drug_concept_id, count(*) drc
		from @cdmDatabaseSchema.drug_exposure
		group by drug_concept_id) co
	join @cdmDatabaseSchema.concept_ancestor ca
		ON ca.descendant_concept_id = co.drug_concept_id
group by ca.ancestor_concept_id
;


