-- 1815  Distribution of numeric values, by measurement_concept_id and unit_concept_id

--HINT DISTRIBUTE_ON_KEY(stratum1_id)
select 1815 as analysis_id,
	CAST(d.stratum1_id AS VARCHAR(255)),
	CAST(d.stratum2_id AS VARCHAR(255)),
	MIN(floor((d.total+99)/100)*100) as count_value,
	MIN(d.min_value) as min_value,
	MIN(d.max_value) as max_value,
	MIN(d.avg_value) as avg_value,
	MIN(d.stdev_value) as stdev_value,
	percentile_disc(0.5) within group (order by count_value) as median_value,
	percentile_disc(0.10) within group (order by count_value) as p10_value,
	percentile_disc(0.25) within group (order by count_value) as p25_value,
	percentile_disc(0.75) within group (order by count_value) as p75_value,
	percentile_disc(0.90) within group (order by count_value) as p90_value
into #tempResults_1815
from (
	select stratum1_id, stratum2_id, count_value,
		cast(sum(total) over (partition by stratum1_id, stratum2_id) AS FLOAT) as total,
		sum(total) over(partition by stratum1_id, stratum2_id order by count_value rows unbounded preceding) as accumulated,
		CAST(avg(1.0 * count_value)  over (partition by stratum1_id, stratum2_id) AS FLOAT) as avg_value,
		CAST(stddev(count_value) over (partition by stratum1_id, stratum2_id) AS FLOAT) as stdev_value,
		min(count_value)  over (partition by stratum1_id, stratum2_id) as min_value,
		max(count_value)  over (partition by stratum1_id, stratum2_id) as max_value	
	from (	
		select measurement_concept_id as stratum1_id, 
				unit_concept_id as stratum2_id,
				CAST(value_as_number AS FLOAT) as count_value,
				count(*) as total
		  from @cdmDatabaseSchema.measurement m
		  where m.unit_concept_id is not null
			and m.value_as_number is not null
		group by measurement_concept_id, unit_concept_id, count_value
	) c	
) d 
group by stratum1_id, stratum2_id
;



--HINT DISTRIBUTE_ON_KEY(stratum_1)
select analysis_id, 
       stratum1_id as stratum_1, 
       stratum2_id as stratum_2, 
       cast(null as varchar(255)) as stratum_3, 
       cast(null as varchar(255)) as stratum_4, 
       cast(null as varchar(255)) as stratum_5,
       count_value, 
       min_value, 
       max_value, 
       avg_value, 
       stdev_value, 
       median_value, 
       p10_value, 
       p25_value, 
       p75_value, 
       p90_value
into @scratchDatabaseSchema@schemaDelim@tempAchillesPrefix_dist_1815
from #tempResults_1815
;

--truncate table #statsView_1815;
--drop table #statsView_1815;

truncate table #tempResults_1815;
drop table #tempResults_1815;
