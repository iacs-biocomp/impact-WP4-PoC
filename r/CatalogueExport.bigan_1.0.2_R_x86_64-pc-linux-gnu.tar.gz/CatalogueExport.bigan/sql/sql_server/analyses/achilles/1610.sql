-- 1610	Number of records by revenue_code_concept_id

{cdmVersion == '5'}?{

	--HINT DISTRIBUTE_ON_KEY(stratum_1)
	select 1610 as analysis_id, 
		CAST(revenue_code_concept_id AS VARCHAR(255)) as stratum_1,
		cast(null as varchar(255)) as stratum_2, cast(null as varchar(255)) as stratum_3, cast(null as varchar(255)) as stratum_4, cast(null as varchar(255)) as stratum_5,
		COUNT_BIG(pc1.procedure_cost_ID) as count_value
	into @scratchDatabaseSchema@schemaDelim@tempAchillesPrefix_1610
	from
		@cdmDatabaseSchema.procedure_cost pc1
	where revenue_code_concept_id is not null
	group by revenue_code_concept_id
	;
	
}:{

	--HINT DISTRIBUTE_ON_KEY(stratum_1)
	select 1610 as analysis_id, 
		CAST(revenue_code_concept_id AS VARCHAR(255)) as stratum_1,
		cast(null as varchar(255)) as stratum_2, cast(null as varchar(255)) as stratum_3, cast(null as varchar(255)) as stratum_4, cast(null as varchar(255)) as stratum_5,
		COUNT_BIG(pc1.cost_id) as count_value
	into @scratchDatabaseSchema@schemaDelim@tempAchillesPrefix_1610
	from
		@cdmDatabaseSchema.cost pc1
	where revenue_code_concept_id is not null
	and pc1.cost_domain_id = 'Procedure'
	group by revenue_code_concept_id
	;

}
